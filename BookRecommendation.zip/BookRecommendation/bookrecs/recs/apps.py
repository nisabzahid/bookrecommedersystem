from django.apps import AppConfig


class RecsConfig(AppConfig):
    name = 'recs'
